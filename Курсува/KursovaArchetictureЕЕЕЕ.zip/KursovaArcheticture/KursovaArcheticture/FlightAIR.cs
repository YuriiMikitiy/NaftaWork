﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace KursovaArcheticture
{
    public class Flight
    {
        public string Route { get; set; }
        public int Number { get; set; }
        public int FlightTime { get; set; }
        public int TicketPrice { get; set; }
        public bool FlightCancellation { get; set; }
        public string Direction { get; set; }
        public int SoldTicket { get; set; }
        public int NumberIssuedTicketsDuringDelay { get; set; }
        public string Type { get; set; }
        public bool DelayedFlight { get; set; }
        public string ReasonFlightDelay { get; set; }
        public string DepartureTime { get; set; }
        public string FlightCategories { get; set; }
        public int NumberPassengers { get; set; }
        public string DepartureDay { get; set; }
    }

    public class FlightAIR
    {
        private const string FilePath = "Flight.txt";
        private List<Flight> flights = new List<Flight>();

        public FlightAIR()
        {
            LoadFlightsFromFile();
        }

        private void LoadFlightsFromFile()
        {
            if (File.Exists(FilePath))
            {
                using (StreamReader file = new StreamReader(FilePath))
                {
                    string line;
                    while ((line = file.ReadLine()) != null)
                    {
                        string[] data = line.Split(' ');

                        if (data.Length >= 15)
                        {
                            Flight flight = new Flight
                            {
                                Route = data[0],
                                Number = Convert.ToInt32(data[1]),
                                FlightTime = Convert.ToInt32(data[2]),
                                TicketPrice = Convert.ToInt32(data[3]),
                                FlightCancellation = Convert.ToBoolean(Convert.ToInt32(data[4])),
                                Direction = data[5],
                                SoldTicket = Convert.ToInt32(data[6]),
                                NumberIssuedTicketsDuringDelay = Convert.ToInt32(data[7]),
                                Type = data[8],
                                DelayedFlight = Convert.ToBoolean(Convert.ToInt32(data[9])),
                                ReasonFlightDelay = data[10],
                                DepartureTime = data[11],
                                FlightCategories = data[12],
                                NumberPassengers = Convert.ToInt32(data[13]),
                                DepartureDay = data[14]
                            };
                            flights.Add(flight);
                        }
                    }
                }
            }
        }

        private void WriteFlightToFile(Flight flight)
        {
            using (StreamWriter file = new StreamWriter(FilePath, true))
            {
                file.WriteLine($"{flight.Route} {flight.Number} {flight.FlightTime} {flight.TicketPrice} " +
                    $"{Convert.ToInt32(flight.FlightCancellation)} {flight.Direction} {flight.SoldTicket} {flight.NumberIssuedTicketsDuringDelay} {flight.Type} " +
                    $"{Convert.ToInt32(flight.DelayedFlight)} {flight.ReasonFlightDelay} {flight.DepartureTime} {flight.FlightCategories} {flight.NumberPassengers} {flight.DepartureDay}");
            }
        }

        private void RewriteFlightsToFile()
        {
            File.WriteAllText(FilePath, string.Empty);
            flights.ForEach(WriteFlightToFile);
        }

        private string ReadInput(string prompt)
        {
            Console.Write(prompt);
            return Console.ReadLine();
        }

        private void ReadFlightData(Flight flight)
        {
            flight.Route = ReadInput("Enter Route: ");
            flight.Number = Convert.ToInt32(ReadInput("Enter Flight Number: "));
            flight.FlightTime = Convert.ToInt32(ReadInput("Enter Flight Time: "));
            flight.TicketPrice = Convert.ToInt32(ReadInput("Enter Ticket Price: "));
            flight.FlightCancellation = Convert.ToBoolean(int.Parse(ReadInput("Is the Flight Cancelled? (1 for Yes, 0 for No): ")));
            flight.Direction = ReadInput("Enter Direction: ");
            flight.SoldTicket = Convert.ToInt32(ReadInput("Enter Sold Ticket Count: "));
            flight.NumberIssuedTicketsDuringDelay = Convert.ToInt32(ReadInput("Enter Number of Issued Tickets During Delay: "));
            flight.Type = ReadInput("Enter Type: ");
            flight.DelayedFlight = Convert.ToBoolean(int.Parse(ReadInput("Is the Flight Delayed? (1 for Yes, 0 for No): ")));
            flight.ReasonFlightDelay = ReadInput("Enter Reason for Flight Delay: ");
            flight.DepartureTime = ReadInput("Enter Departure Time: ");
            flight.FlightCategories = ReadInput("Enter Flight Categories: ");
            flight.NumberPassengers = Convert.ToInt32(ReadInput("Enter Number of Passengers: "));
            flight.DepartureDay = ReadInput("Enter Departure Day: ");
        }

        public void AddFlight()
        {
            Flight flight = new Flight();
            ReadFlightData(flight);
            flights.Add(flight);
            WriteFlightToFile(flight);
            Console.WriteLine("Flight data added successfully.");
        }

        public void UpdateFlight(int flightNumber)
        {
            Flight flightToUpdate = flights.FirstOrDefault(f => f.Number == flightNumber);
            if (flightToUpdate != null)
            {
                Console.WriteLine($"Updating flight with number: {flightNumber}");
                ReadFlightData(flightToUpdate);
                RewriteFlightsToFile();
                Console.WriteLine("Flight data updated successfully.");
            }
            else
            {
                Console.WriteLine($"Flight with number {flightNumber} not found.");
            }
        }

        public void DeleteFlight(int flightNumber)
        {
            Flight flightToDelete = flights.FirstOrDefault(f => f.Number == flightNumber);
            if (flightToDelete != null)
            {
                flights.Remove(flightToDelete);
                RewriteFlightsToFile();
                Console.WriteLine($"Flight with number {flightNumber} deleted.");
            }
            else
            {
                Console.WriteLine($"Flight with number {flightNumber} not found.");
            }
        }

        private void OutputFlight(Flight flight)
        {
            Console.WriteLine($"Route: {flight.Route}");
            Console.WriteLine($"Number: {flight.Number}");
            Console.WriteLine($"Flight time: {flight.FlightTime}");
            Console.WriteLine($"Ticket price: {flight.TicketPrice}");
            Console.WriteLine($"Flight cancellation: {(flight.FlightCancellation ? "Yes" : "No")}");
            Console.WriteLine($"Direction: {flight.Direction}");
            Console.WriteLine($"Sold ticket: {flight.SoldTicket}");
            Console.WriteLine($"Number of issued tickets during delay: {flight.NumberIssuedTicketsDuringDelay}");
            Console.WriteLine($"Type: {flight.Type}");
            Console.WriteLine($"Delayed flight: {(flight.DelayedFlight ? "Yes" : "No")}");
            Console.WriteLine($"Reason for flight delay: {flight.ReasonFlightDelay}");
            Console.WriteLine($"Departure time: {flight.DepartureTime}");
            Console.WriteLine($"Flight categories: {flight.FlightCategories}");
            Console.WriteLine($"Number of passengers: {flight.NumberPassengers}");
            Console.WriteLine($"Departure day: {flight.DepartureDay}");
            Console.WriteLine();
        }

        private void GetFlights(Func<Flight, bool> predicate, string message)
        {
            var filteredFlights = flights.Where(predicate).ToList();
            filteredFlights.ForEach(OutputFlight);
            Console.WriteLine($"\n{message}: {filteredFlights.Count}");
        }

        public void GetFlightsSpecifiedRoute(string route) =>
            GetFlights(f => f.Route == route, "Number of flights");

        public void GetFlightsTime(int flightTime) =>
            GetFlights(f => f.FlightTime == flightTime, "Number of flights");

        public void GetFlightsTicketPrice(int ticketPrice) =>
            GetFlights(f => f.TicketPrice == ticketPrice, "Number of flights");

        public void GetFlightsAllCriteria(string route, int flightTime, int ticketPrice) =>
            GetFlights(f => f.Route == route && f.FlightTime == flightTime && f.TicketPrice == ticketPrice, "Number of flights");

        public void GetFlightsCanceledFlightsFull() =>
            GetFlights(f => f.FlightCancellation, "Number of flights");

        public void GetFlightsCanceledDirection(string direction) =>
            GetFlights(f => f.FlightCancellation && f.Direction == direction, "Number of flights");

        public void GetFlightsCanceledSpecifiedRoute(string route) =>
            GetFlights(f => f.FlightCancellation && f.Route == route, "Number of flights");

        public void GetFlightsCancelUnclaimedSeats(int seats) =>
            GetFlights(f => f.FlightCancellation && (120 - f.NumberPassengers) == seats, "Number of flights");

        public void GetFlightsCancelPercentage(int percentage) =>
            GetFlights(f => f.FlightCancellation && ((120 - f.NumberPassengers) * 10 / 12) == percentage, "Number of flights");

        public void GetFlightsAllDelayed() =>
            GetFlights(f => f.DelayedFlight, "Number of flights");

        public void GetFlightsReasonFlightDelay(string reasonFlightDelay) =>
            GetFlights(f => f.DelayedFlight && f.ReasonFlightDelay == reasonFlightDelay, "Number of flights");

        public void GetFlightsDelayedSpecifiedRoute(string route) =>
            GetFlights(f => f.DelayedFlight && f.Route == route, "Number of flights");

        public void GetFlightsDelayedTicketsDuringDelay(int numberIssuedTicketsDuringDelay) =>
            GetFlights(f => f.DelayedFlight && f.NumberIssuedTicketsDuringDelay == numberIssuedTicketsDuringDelay, "Number of flights");

        public void GetAllFlightsTypeAvarage(string type)
        {
            var filteredFlights = flights.Where(f => f.Type == type).ToList();
            if (filteredFlights.Any())
            {
                int totalSoldTickets = filteredFlights.Sum(f => f.SoldTicket);
                Console.WriteLine("Number of flights: " + filteredFlights.Count);
                Console.WriteLine("The average number of sold tickets for certain routes: " + (totalSoldTickets / filteredFlights.Count));
            }
            else
            {
                Console.WriteLine("No flights found for the specified type.");
            }
        }

        public void GetAllFlightDuration(int flightTime) =>
            GetFlights(f => f.FlightTime == flightTime, "Number of flights");

        public void GetAllFlightDepartureTime(string departureTime) =>
            GetFlights(f => f.DepartureTime == departureTime, "Number of flights");

        public void GetAllFlightCategories(string flightCategories) =>
            GetFlights(f => f.FlightCategories == flightCategories, "Number of flights");

        public void GetAllFlightDirection(string direction) =>
            GetFlights(f => f.Direction == direction, "Number of flights");

        public void GetAllFlightIsuedTickets(string flight) =>
            Console.WriteLine("The number of issued tickets: " + flights.Where(f => f.Route == flight).Sum(f => f.NumberIssuedTicketsDuringDelay));

        public void GetAllFlightIsuedTicketsInDay(string day) =>
            Console.WriteLine("The number of issued tickets: " + flights.Where(f => f.DepartureDay == day).Sum(f => f.NumberIssuedTicketsDuringDelay));

        public void GetAllFlightIsuedTicketsDirection(string direction) =>
            Console.WriteLine("The number of issued tickets: " + flights.Where(f => f.Direction == direction).Sum(f => f.NumberIssuedTicketsDuringDelay));

        public void GetAllFlightIsuedTicketsPrice(int ticketPrice) =>
            Console.WriteLine("The number of issued tickets: " + flights.Where(f => f.TicketPrice == ticketPrice).Sum(f => f.NumberIssuedTicketsDuringDelay));
    }
}