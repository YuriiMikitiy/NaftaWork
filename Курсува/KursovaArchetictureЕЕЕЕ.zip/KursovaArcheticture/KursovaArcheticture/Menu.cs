﻿using KursovaArcheticture;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Transactions;
using System.Xml.Linq;

namespace KursovaArcheticture
{
    internal class Menu
    {
        static void pause()
        {
            Console.WriteLine("Press key \"Esc\" to exit...");
            if (Console.ReadKey().Key == ConsoleKey.Escape)
            {
                Environment.Exit(0);
            }
        }

        static void GetInputAndCallMethod(string prompt, Action<string> method)
        {
            Console.Clear();
            Console.Write(prompt);
            string input = Console.ReadLine();
            method(input);
            pause();
        }
        public void menu()
        {
            Console.Clear();
            WorkerAIR worker = new WorkerAIR();
            PlaneAIR plane = new PlaneAIR();
            FlightAIR flight = new FlightAIR();
            PassengerAIR passenger = new PassengerAIR();
            
            int option=0;
            do
            {
                try
                {
                Console.WriteLine("Select an option:\n");
                Console.WriteLine("1. Employees");
                Console.WriteLine("2. Employee details (flight, age, salary)");
                Console.WriteLine("3. Pilots (medical exam, filter by years, sex, age)");
                Console.WriteLine("4. Planes (time, arrival, number of flights)");
                Console.WriteLine("5. Aircraft state (service, age, repairs, flights before repair)");
                Console.WriteLine("6. Flights (route, duration, price, all criteria)");
                Console.WriteLine("7. Canceled flights (direction, route, unclaimed seats)");
                Console.WriteLine("8. Delayed flights (reason, route, issued tickets)");
                Console.WriteLine("9. Flight list (aircraft type, tickets sold, duration, price, departure)");
                Console.WriteLine("10. Flight list (category, direction, aircraft type)");
                Console.WriteLine("11. Passengers (flight, departure day, international, baggage, gender, age)");
                Console.WriteLine("12. Free & reserved seats (flight, day, route, price, departure)");
                Console.WriteLine("13. Ticket count (flight, day, route, price, age, gender)");
                Console.WriteLine("14. Go to Admin mod\n");
                Console.WriteLine("15. Exit\n");
                 
                Console.Write("Enter your option: ");
                option = Convert.ToInt32(Console.ReadLine()); 
                switch (option)
                {
                    case 1:
                        Console.Clear();
                        Console.WriteLine("Select a request:\n");
                        Console.WriteLine("1. Get a list of all employees and their number");
                        Console.WriteLine("2. Get a list of department heads");
                        Console.WriteLine("3. Get a list of employees of the department");
                        Console.WriteLine("4. Get a list of employees with experience (in years)");
                        Console.WriteLine("5. Get a list of employees with a specific sexual characteristic"); 
                        Console.WriteLine("6. Get a list of employees within a certain age range");
                        Console.WriteLine("7. Get the number of children of an employee");
                        Console.WriteLine("8. Get the amount of the employee's salary (consider privacy implications)");
                        Console.WriteLine("9. Exit\n");
                        Console.Write("Enter your option: ");
                        int choice_1 = Convert.ToInt32(Console.ReadLine());
                        switch (choice_1)
                        {
                            case 1:
                                Console.Clear();
                                worker.GetOllWorkers();
                                pause();
                                break;
                            case 2:
                                Console.Clear();
                                worker.GetOllDepartmentHeads();
                                pause();
                                break;
                            case 3:
                                GetInputAndCallMethod("1.Pilots \n2.Dispatchers \n3.Technigues \n4.Cashieres \n5.Security \n6.Directory service \nEnter department (1-6): ", input => worker.GetOllEmployeesDepartment(Convert.ToInt32(input)));
                                break;
                            case 4:
                                GetInputAndCallMethod("Enter experience: ", input => worker.PrintWorkersWithExperience(Convert.ToInt32(input)));
                                break;
                            case 5:
                                GetInputAndCallMethod("Enter sexual characteristic(M/F): ", input => worker.GetOllEmployeeSexualCharacteristic(Convert.ToChar(input)));
                                break;
                            case 6:
                                GetInputAndCallMethod("Enter age: ", input => worker.GetOllEmployeesAge(Convert.ToInt32(input)));
                                break;
                            case 7:
                                GetInputAndCallMethod("Enter number children: ", input => worker.GetOllEmployeesNumberChildren(Convert.ToInt32(input)));
                                break;
                            case 8:
                                GetInputAndCallMethod("Enter the salary amount: ", input => worker.GetOllEmployeeSalary(Convert.ToInt32(input)));
                                break;
                        }
                        Console.Clear();
                        break;
                    case 2:
                        Console.Clear();
                        Console.WriteLine("Select a request:");
                        Console.WriteLine("1.Get workers in the brigade");
                        Console.WriteLine("2.Get workers in oll department");
                        Console.WriteLine("3.Get workers in the department");
                        Console.WriteLine("4.Get a list of employees by serviced flight");
                        Console.WriteLine("5.Get a list of employees with age");
                        Console.WriteLine("6.Get a list of employees total average salary in brigade");
                        Console.WriteLine("7. Exit");
                        int choice_2 = Convert.ToInt32(Console.ReadLine());
                        switch (choice_2)
                        {
                            case 1:
                                GetInputAndCallMethod("Enter brigade(1-3): ", input => worker.GetOllEmployeeInBrigade(Convert.ToInt32(input)));
                                break;
                            case 2:
                                Console.Clear();
                                worker.GetOllEmployeeInOllBrigade();
                                pause();
                                break;
                            case 3:
                                GetInputAndCallMethod("1.Pilots \n2.Dispatchers \n3.Technigues \n4.Cashieres \n5.Security \n6.Directory service \nEnter department (1-6): ", input => worker.GetOllEmployeesDepartment(Convert.ToInt32(input)));
                                break;
                            case 4:
                                GetInputAndCallMethod("Enter flight: ", input => worker.GetOllEmployeeServingSpecificFlight(input));
                                break;
                            case 5:
                                GetInputAndCallMethod("Enter age: ", input => worker.GetOllEmployeesAge(Convert.ToInt32(input)));
                                break;
                            case 6:
                                GetInputAndCallMethod("Enter brigade(1-3): ", input => worker.GetOllEmployeeTotalAverageSalaryBrigade(Convert.ToInt32(input)));
                                break;
                        }
                        Console.Clear();
                        break;
                    case 3:
                        Console.Clear();
                        Console.WriteLine("Select a request:\n");
                        Console.WriteLine("Get a list of pilots:");
                        Console.WriteLine("1.who have passed a medical examination");
                        Console.WriteLine("2.who did not pass it in the specified year");
                        Console.WriteLine("3.with sexual characteristic");
                        Console.WriteLine("4.with age");
                        Console.WriteLine("5.Get the amount of pilots salary");
                        Console.WriteLine("6. Exit");
                        int choice_3 = Convert.ToInt32(Console.ReadLine());
                        switch (choice_3)
                        {
                            case 1:
                                Console.Clear();
                                worker.GetOllPilotsMedicalExamination();
                                pause();
                                break;
                            case 2:
                                GetInputAndCallMethod("Enter year: ", input => worker.GetOllPilotsNotMedicalExaminationYear(Convert.ToInt32(input)));
                                break;
                            case 3:
                                GetInputAndCallMethod("Enter sexual characteristic(M/F): ", input => worker.GetOllEmployeeGenderPilots(Convert.ToChar(input)));
                                break;
                            case 4:
                                GetInputAndCallMethod("Enter age: ", input => worker.GetOllPilotsAge(Convert.ToInt32(input)));
                                break;
                            case 5:
                                GetInputAndCallMethod("Enter the salary amount: ", input => worker.GetOllPilotsSalary(Convert.ToInt32(input)));
                                break;
                        }
                        Console.Clear();
                        break;
                    case 4:
                        Console.Clear();
                        Console.WriteLine("Select a request:");
                        Console.WriteLine("1.Get a list of all plane and their number");
                        Console.WriteLine("2.Get a list of all the planes that are at the airport at the specified time");
                        Console.WriteLine("3.Get a list and the total number of planes by arrival time at the airport");
                        Console.WriteLine("4.Get a list and the total number of planes by the number of flights made.");
                        Console.WriteLine("5. Exit");
                        int choice_4 = Convert.ToInt32(Console.ReadLine());
                        switch (choice_4)
                        {
                            case 1:
                                Console.Clear();
                                plane.GetOllPlanes();
                                pause();
                                break;
                            case 2:
                                GetInputAndCallMethod("Enter time: ", input => plane.GetOllPlanesAtSpecifiedTime(input));
                                break;
                            case 3:
                                GetInputAndCallMethod("Enter time: ", input => plane.GetOllPlanesAtSpecifiedTime(input));
                                break;
                            case 4:
                                GetInputAndCallMethod("Enter number flights made: ", input => plane.GetOllNumberFlightsMade(Convert.ToInt32(input)));
                                break;
                        }
                        Console.Clear();
                        break;
                    case 5:
                        Console.Clear();
                        Console.WriteLine("Select a request:\n");
                        Console.WriteLine("Get a list and the total number of aircraft:");
                        Console.WriteLine("1.that have passed technical inspection for a certain period of time");
                        Console.WriteLine("2.sent for repair at the specified time");
                        Console.WriteLine("3.repaired a given number of times");
                        Console.WriteLine("4.according to the number of flights before repair");
                        Console.WriteLine("5.by age of the aircraft.");
                        Console.WriteLine("6. Exit");
                        int choice_5 = Convert.ToInt32(Console.ReadLine());
                        switch (choice_5)
                        {
                            case 1:
                                GetInputAndCallMethod("Enter a time period (morning, noon, evening, night): ", input => plane.GetOllPeriodTimeTechnical(input));
                                break;
                            case 2:
                                GetInputAndCallMethod("Enter day sending repair: ", input => plane.GetOllDaySendingRepair(input));
                                break;
                            case 3:
                                GetInputAndCallMethod("Enter number repairs: ", input => plane.GetOllNumberRepairs(Convert.ToInt32(input)));
                                break;
                            case 4:
                                GetInputAndCallMethod("Enter number flights repaired: ", input => plane.GetOllNumberFlightsRepaired(Convert.ToInt32(input)));
                                break;
                            case 5:
                                GetInputAndCallMethod("Enter age aircraft: ", input => plane.GetOllAgeAircraft(Convert.ToInt32(input)));
                                break;
                        }
                        Console.Clear();
                        break;
                    case 6:
                        Console.Clear();
                        Console.WriteLine("Select a request:\n");
                        Console.WriteLine("Get a list of flights:");
                        Console.WriteLine("1.on the specified route");
                        Console.WriteLine("2.by flight duration");
                        Console.WriteLine("3.by ticket price");
                        Console.WriteLine("4.by all criteria at once");
                        Console.WriteLine("5.Exit");
                        int choice_6 = Convert.ToInt32(Console.ReadLine());
                        switch (choice_6)
                        {
                            case 1:
                                GetInputAndCallMethod("Enter route: ", input => flight.GetFlightsSpecifiedRoute(input));
                                break;
                            case 2:
                                GetInputAndCallMethod("Enter flight time: ", input => flight.GetFlightsTime(Convert.ToInt32(input)));
                                break;
                            case 3:
                                GetInputAndCallMethod("Enter ticket price: ", input => flight.GetFlightsTicketPrice(Convert.ToInt32(input)));
                                break;
                            case 4:
                                    GetInputAndCallMethod("Enter route: ", route =>
                                    {
                                        Console.Write("Enter flight time(minute): ");
                                        int flightTime = Convert.ToInt32(Console.ReadLine());
                                        Console.Write("Enter ticket price: ");
                                        int ticketPrice = Convert.ToInt32(Console.ReadLine());
                                        flight.GetFlightsAllCriteria(route, flightTime, ticketPrice);
                                    });
                                    break;
                        }
                        Console.Clear();
                        break;
                    case 7:
                        Console.Clear();
                        Console.WriteLine("Select a request:\n");
                        Console.WriteLine("Get a list and total number of canceled flights:");
                        Console.WriteLine("1.In full");
                        Console.WriteLine("2.At the indicated direction");
                        Console.WriteLine("3.On the specified route");
                        Console.WriteLine("4.By the number of unclaimed seats");
                        Console.WriteLine("5.In full by the percentage of unclaimed seats");
                        Console.WriteLine("6. Exit");
                        int choice_7 = Convert.ToInt32(Console.ReadLine());
                        switch (choice_7)
                        {
                            case 1:
                                Console.Clear();
                                flight.GetFlightsCanceledFlightsFull();
                                pause();
                                break;
                            case 2:
                                GetInputAndCallMethod("Enter direction: ", input => flight.GetFlightsCanceledDirection(input));
                                break;
                            case 3:
                                GetInputAndCallMethod("Enter route: ", input => flight.GetFlightsCanceledSpecifiedRoute(input));
                                break;
                            case 4:
                                GetInputAndCallMethod("Enter seats: ", input => flight.GetFlightsCancelUnclaimedSeats(Convert.ToInt32(input)));
                                break;
                            case 5:
                                GetInputAndCallMethod("Enter a number as a percentage: ", input => flight.GetFlightsCancelPercentage(Convert.ToInt32(input)));
                                break;
                        }
                        Console.Clear();
                        break;
                    case 8:
                        Console.Clear();
                        Console.WriteLine("Select a request:\n");
                        Console.WriteLine("Get a list and total number of delayed flights:");
                        Console.WriteLine("1.Get a list and total number of delayed flights");
                        Console.WriteLine("2.fromthe specified reason");
                        Console.WriteLine("3.on the specified route");
                        Console.WriteLine("4.for the number of issued tickets during the delay.");
                        Console.WriteLine("5.Exit");
                        int choice_8 = Convert.ToInt32(Console.ReadLine());
                        switch (choice_8)
                        {
                            case 1:
                                Console.Clear();
                                flight.GetFlightsAllDelayed();
                                pause();
                                break;
                            case 2:
                                GetInputAndCallMethod("Enter reason for flight delay: ", input => flight.GetFlightsReasonFlightDelay(input));
                                break;
                            case 3:
                                GetInputAndCallMethod("Enter route: ", input => flight.GetFlightsDelayedSpecifiedRoute(input));
                                break;
                            case 4:
                                GetInputAndCallMethod("Enter the number of tickets issued during the delay: ", input => flight.GetFlightsDelayedTicketsDuringDelay(Convert.ToInt32(input)));
                                break;
                        }
                        Console.Clear();
                        break;
                    case 9:
                        Console.Clear();
                        Console.WriteLine("Select a request:\n");
                        Console.WriteLine("Get a list and the total number of flights:");
                        Console.WriteLine("1.operated by aircraft of a given type");
                        Console.WriteLine("2.by flight duration");
                        Console.WriteLine("3.by ticket price");
                        Console.WriteLine("4.by departure time");
                        Console.WriteLine("5.Exit");
                        int choice_9 = Convert.ToInt32(Console.ReadLine());
                        switch (choice_9)
                        {
                            case 1:
                                GetInputAndCallMethod("Enter type: ", input => flight.GetAllFlightsTypeAvarage(input));
                                break;
                            case 2:
                                GetInputAndCallMethod("Enter flight time(in hourse): ", input => flight.GetAllFlightDuration(Convert.ToInt32(input)));
                                break;
                            case 3:
                                GetInputAndCallMethod("Enter ticket price: ", input => flight.GetFlightsTicketPrice(Convert.ToInt32(input)));
                                break;
                            case 4:
                                GetInputAndCallMethod("Enter departure time: ", input => flight.GetAllFlightDepartureTime(input));
                                break;
                        }
                        Console.Clear();
                        break;
                    case 10:
                        Console.Clear();
                        Console.WriteLine("Select a request:\n");
                        Console.WriteLine("Get a list and total number of flights:");
                        Console.WriteLine("1.of the specified category");
                        Console.WriteLine("2.in a certain direction");
                        Console.WriteLine("3.Exit");
                        int choice_10 = Convert.ToInt32(Console.ReadLine());
                        switch (choice_10)
                        {
                            case 1:
                                GetInputAndCallMethod("Enter flight categories: ", input => flight.GetAllFlightCategories(input));
                                break;
                            case 2:
                                GetInputAndCallMethod("Enter direction: ", input => flight.GetAllFlightDirection(input));
                                break;
                        }
                        Console.Clear();
                        break;
                    case 11:
                        Console.Clear();
                        Console.WriteLine("Select a request:\n");
                        Console.WriteLine("Get a list and the total number of passengers on this flight:");
                        Console.WriteLine("1.who departed on the specified day");
                        Console.WriteLine("2.who flew abroad on the specified day");
                        Console.WriteLine("3.according to the indication of the baggage claim");
                        Console.WriteLine("4.by gender");
                        Console.WriteLine("5.by age.");
                        Console.WriteLine("6.Exit");
                        int choice_11 = Convert.ToInt32(Console.ReadLine());
                        switch (choice_11)
                        {
                            case 1:
                                GetInputAndCallMethod("Enter day(dd/mm/yyyy): ", input => passenger.GetAllPassengersDepartedSpecifiedDay(input));
                                break;
                            case 2:
                                GetInputAndCallMethod("Enter day(dd/mm/yyyy): ", input => passenger.GetAllPassengersDepartedSpecifiedDayFlewAbroad(input));
                                break;
                            case 3:
                                GetInputAndCallMethod("Has the passenger checked in luggage (1 for yes, 0 for no): ", input =>
                                {
                                    bool checkedLuggage = Convert.ToInt32(input) == 1;
                                    passenger.GetAllPassengersCheckedBaggage(checkedLuggage);
                                });
                                break;
                            case 4:
                                GetInputAndCallMethod("Enter passenger gender (M/F): ", input => passenger.GetAllNumbersGender(Convert.ToChar(input)));
                                break;
                            case 5:
                                GetInputAndCallMethod("Enter passenger age: ", input => passenger.GetAllPassengersAge(Convert.ToInt32(input)));
                                break;
                        }
                        Console.Clear();
                        break;
                    case 12:
                        Console.Clear();
                        Console.WriteLine("Select a request:\n");
                        Console.WriteLine("Get a list and the total number of free and reserved seats:");
                        Console.WriteLine("1.on the specified flight");
                        Console.WriteLine("2.for the specified day");
                        Console.WriteLine("3.according to the specified route");
                        Console.WriteLine("4.by price");
                        Console.WriteLine("5.by departure time.");
                        Console.WriteLine("6.Exit");
                        int choice_12 = Convert.ToInt32(Console.ReadLine());
                        switch (choice_12)
                        {
                            case 1:
                                GetInputAndCallMethod("Enter flight: ", input => passenger.GetFreeReservedPlacesFlight(input));
                                break;
                            case 2:
                                GetInputAndCallMethod("Enter departure day: ", input => passenger.GetFreeReservedPlacesDepartureDay(input));
                                break;
                            case 3:
                                GetInputAndCallMethod("Enter flight: ", input => passenger.GetFreeReservedPlacesFlight(input));
                                break;
                            case 4:
                                GetInputAndCallMethod("Enter ticket price: ", input => passenger.GetFreeReservedPlacesTicketPrice(Convert.ToInt32(input)));
                                break;
                            case 5:
                                GetInputAndCallMethod("Enter departure time: ", input => passenger.GetFreeReservedPlacesDepartureTime(input));
                                break;
                        }
                        Console.Clear();
                        break;
                    case 13:
                        Console.Clear();
                        Console.WriteLine("Select a request:\n");
                        Console.WriteLine("Get the total number of:");
                        Console.WriteLine("1.issued tickets for a certain flight");
                        Console.WriteLine("2.issued tickets on the specified day");
                        Console.WriteLine("3.given tickets for a specific route");
                        Console.WriteLine("4.issued tickets by ticket price");
                        Console.WriteLine("5.issued tickets by age");
                        Console.WriteLine("6.issued tickets for a certain flight, by gender");
                        Console.WriteLine("7.Exit");
                        int choice_13 = Convert.ToInt32(Console.ReadLine());
                        switch (choice_13)
                        {
                            case 1:
                                GetInputAndCallMethod("Enter flights: ", input => flight.GetAllFlightIsuedTickets(input));
                                break;
                            case 2:
                                GetInputAndCallMethod("Enter day(DD.MM.YYYY): ", input => flight.GetAllFlightIsuedTicketsInDay(input));
                                break;
                            case 3:
                                GetInputAndCallMethod("Enter direction: ", input => flight.GetAllFlightIsuedTicketsDirection(input));
                                break;
                            case 4:
                                GetInputAndCallMethod("Enter ticket price: ", input => flight.GetAllFlightIsuedTicketsPrice(Convert.ToInt32(input)));
                                break;
                            case 5:
                                GetInputAndCallMethod("Enter age: ", input => passenger.GetAllNumbersAge(Convert.ToInt32(input)));
                                break;
                            case 6:
                                GetInputAndCallMethod("Enter gender (M/F): ", input => passenger.GetAllNumbersGender(Convert.ToChar(input)));
                                break;
                        }
                        Console.Clear();
                        break;
                    case 14:
                            Console.Clear();
                            Administration();
                            break;
                    case 15:
                        Console.Clear();
                        Environment.Exit(0);
                        break;
                    default:
                        Console.Clear();//////////////////
                        Console.Write("Invalid option. Try again.");
                        continue;
                }

                }
                catch (FormatException)
                {
                    Console.Clear();
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Введено не коректне значення!");
                    Console.ForegroundColor = ConsoleColor.Black;
                    continue;
                }
            } while (option != 16);
        }

        public void Administration()
        {
            Console.Clear();
            WorkerAIR worker = new WorkerAIR();
            PlaneAIR plane = new PlaneAIR();
            FlightAIR flight = new FlightAIR();
            PassengerAIR passenger = new PassengerAIR();
            int option = 0;

            Console.WriteLine("\t\t\tAre you Administrator?\n");
            Console.WriteLine("\t\t\t(1 for Yes, 0 for No):");
            int.TryParse(Console.ReadLine(), out option);
            if (option == 1)
            {
                int password;
                Console.WriteLine("\t\t\tPlease enter password:");
                int.TryParse(Console.ReadLine(), out password);
                if (password == 4444)
                {
                    Console.Clear();
                    do
                    {
                        try
                        {
                            Console.WriteLine("Select an option:");

                            Console.WriteLine("\nAdd Data: ");
                            Console.WriteLine("1. Add Worker");
                            Console.WriteLine("2. Add Plane");
                            Console.WriteLine("3. Add Flight");
                            Console.WriteLine("4. Add Passenger");

                            Console.WriteLine("\nUpdate Data: ");
                            Console.WriteLine("5. Update Worker");
                            Console.WriteLine("6. Update Plane");
                            Console.WriteLine("7. Update Flight");
                            Console.WriteLine("8. Updateter Passenger");

                            Console.WriteLine("\nDelete Data: ");
                            Console.WriteLine("9. Delete Worker");
                            Console.WriteLine("10. Delete Plane");
                            Console.WriteLine("11. Delete Flight");
                            Console.WriteLine("12. Delete Passenger");

                            Console.WriteLine("\n13. Menu for user");

                            Console.WriteLine("14. Exit");

                            Console.Write("\nEnter your option: ");
                            option = Convert.ToInt32(Console.ReadLine());

                            switch (option)
                            {
                                case 1:
                                    Console.Clear();
                                    worker.AddWorker();
                                    continue;
                                case 2:
                                    Console.Clear();
                                    plane.AddPlane();
                                    continue;
                                case 3:
                                    Console.Clear();
                                    flight.AddFlight();
                                    continue;
                                case 4:
                                    Console.Clear();
                                    passenger.AddPassenger();
                                    continue;
                                case 5:
                                    GetInputAndCallMethod("Enter name: ", input => worker.UpdateWorker(input));
                                    continue;
                                case 6:
                                    GetInputAndCallMethod("Enter flight: ", input => plane.UpdatePlane(input));
                                    continue;
                                case 7:
                                    GetInputAndCallMethod("Enter number: ", input => flight.UpdateFlight(Convert.ToInt32(input)));
                                    continue;
                                case 8:
                                    GetInputAndCallMethod("Enter name: ", input => passenger.UpdatePassenger(input));
                                    continue;
                                case 9:
                                    GetInputAndCallMethod("Enter name: ", input => worker.DeleteWorker(input));
                                    continue;
                                case 10:
                                    GetInputAndCallMethod("Enter flight: ", input => plane.DeletePlane(input));
                                    continue;
                                case 11:
                                    GetInputAndCallMethod("Enter name: ", input => flight.DeleteFlight(Convert.ToInt32(input)));
                                    continue;
                                case 12:
                                    GetInputAndCallMethod("Enter name: ", input => passenger.DeletePassenger(input));
                                    continue;
                                case 13:
                                    Console.Clear();
                                    menu();
                                    continue;
                                case 14:
                                    Environment.Exit(0);
                                    continue;
                                default:
                                    Console.WriteLine("Invalid option. Try again.");
                                    continue;
                            }
                        }
                        catch (FormatException)
                        {
                            Console.Clear();
                            Console.Clear();
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("Введено не коректне значення!");
                            Console.ForegroundColor = ConsoleColor.Black;
                            continue;
                        }

                    } while (option !=14);
                    
                }
                else
                {
                    Console.WriteLine("You are not the admin you will be quiet");
                    Environment.Exit(0);
                }
            }
        }
    }
}