﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;

namespace KursovaArcheticture
{
    public class Plane
    {
        public string type { get; set; }
        public int age_aircraft { get; set; }
        public string flight { get; set; }
        public int number_seats { get; set; }
        public string time_spent_airport { get; set; }
        public string time_arrival_airport { get; set; }
        public int number_flights_made { get; set; }
        public bool passed_technical_inspection { get; set; }
        public string period_time_technical_inspection { get; set; }
        public bool sent_repair { get; set; }
        public string day_sending_repair { get; set; }
        public int number_repairs { get; set; }
        public int number_flights_repaired { get; set; }
    }

    public class PlaneAIR
    {
        private List<Plane> planes = new List<Plane>();
        private const string FilePath = "Plane.txt";

        public void AddPlane()
        {
            Plane p = InputPlaneData();
            planes.Add(p);
            WritePlaneToFile(p);
            Console.Clear();
        }

        public void UpdatePlane(string flight)
        {
            Plane planeToUpdate = planes.Find(p => p.flight == flight);
            if (planeToUpdate != null)
            {
                Console.WriteLine($"Updating plane with flight: {flight}");
                InputPlaneData(planeToUpdate);
                RewritePlanesToFile();
                Console.Clear();
            }
            else
            {
                Console.WriteLine($"Plane with flight {flight} not found.");
            }
        }

        public void DeletePlane(string flight)
        {
            Plane planeToDelete = planes.Find(p => p.flight == flight);
            if (planeToDelete != null)
            {
                planes.Remove(planeToDelete);
                RewritePlanesToFile();
                Console.WriteLine($"Plane with flight {flight} deleted.");
            }
            else
            {
                Console.WriteLine($"Plane with flight {flight} not found.");
            }
        }

        private Plane InputPlaneData(Plane p = null)
        {
            p ??= new Plane();

            Console.Write("Enter plane type: ");
            p.type = Console.ReadLine();

            Console.Write("Enter age of aircraft: ");
            p.age_aircraft = int.Parse(Console.ReadLine());

            Console.Write("Enter flight: ");
            p.flight = Console.ReadLine();

            Console.Write("Enter number of seats: ");
            p.number_seats = int.Parse(Console.ReadLine());

            Console.Write("Enter time spent at airport (format: HH:MM): ");
            p.time_spent_airport = Console.ReadLine();

            Console.Write("Enter time of arrival at airport (format: HH:MM): ");
            p.time_arrival_airport = Console.ReadLine();

            Console.Write("Enter number of flights made: ");
            p.number_flights_made = int.Parse(Console.ReadLine());

            Console.Write("Has the plane passed technical inspection? (Yes/No): ");
            p.passed_technical_inspection = Console.ReadLine().Equals("Yes", StringComparison.OrdinalIgnoreCase);

            Console.Write("Enter period of time for technical inspection: ");
            p.period_time_technical_inspection = Console.ReadLine();

            Console.Write("Is the plane sent for repair? (Yes/No): ");
            p.sent_repair = Console.ReadLine().Equals("Yes", StringComparison.OrdinalIgnoreCase);

            Console.Write("Enter day sent for repair (format: DD/MM/YYYY): ");
            p.day_sending_repair = Console.ReadLine();

            Console.Write("Enter number of repairs: ");
            p.number_repairs = int.Parse(Console.ReadLine());

            Console.Write("Enter number of flights repaired: ");
            p.number_flights_repaired = int.Parse(Console.ReadLine());

            return p;
        }

        private void RewritePlanesToFile()
        {
            File.WriteAllText(FilePath, string.Empty);
            foreach (Plane p in planes)
            {
                WritePlaneToFile(p);
            }
        }

        private void WritePlaneToFile(Plane p)
        {
            using (StreamWriter file = new StreamWriter(FilePath, true))
            {
                file.WriteLine($"{p.type} {p.age_aircraft} {p.flight} {p.number_seats} " +
                    $"{p.time_spent_airport} {p.time_arrival_airport} {p.number_flights_made} {Convert.ToInt32(p.passed_technical_inspection)} {p.period_time_technical_inspection} " +
                    $"{Convert.ToInt32(p.sent_repair)} {p.day_sending_repair} {p.number_repairs} {p.number_flights_repaired}");
            }
        }

        public void DataOutputPlane(Plane p)
        {
            Console.WriteLine("Type: " + p.type);
            Console.WriteLine("Age of the aircraft: " + p.age_aircraft);
            Console.WriteLine("Flight: " + p.flight);
            Console.WriteLine("Number of seats: " + p.number_seats);
            Console.WriteLine("Time spent at airport: " + p.time_spent_airport);
            Console.WriteLine("Time of arrival at airport: " + p.time_arrival_airport);
            Console.WriteLine("Number of flights made: " + p.number_flights_made);
            Console.WriteLine("Passed technical inspection: " + (p.passed_technical_inspection ? "Yes" : "No"));
            Console.WriteLine("Period of time for technical inspection: " + p.period_time_technical_inspection);
            Console.WriteLine("Sent for repair: " + (p.sent_repair ? "Yes" : "No"));
            Console.WriteLine("Day sent for repair: " + p.day_sending_repair);
            Console.WriteLine("Number of repairs: " + p.number_repairs);
            Console.WriteLine("Number of flights repaired: " + p.number_flights_repaired);
            Console.WriteLine();
        }

        public PlaneAIR()
        {
            if (File.Exists(FilePath))
            {
                using (StreamReader file = new StreamReader(FilePath))
                {
                    string line;
                    while ((line = file.ReadLine()) != null)
                    {
                        string[] data = line.Split(' ');

                        if (data.Length >= 13)
                        {
                            Plane p = new Plane()
                            {
                                type = data[0],
                                age_aircraft = Convert.ToInt32(data[1]),
                                flight = data[2],
                                number_seats = Convert.ToInt32(data[3]),
                                time_spent_airport = data[4],
                                time_arrival_airport = data[5],
                                number_flights_made = Convert.ToInt32(data[6]),
                                passed_technical_inspection = Convert.ToBoolean(Convert.ToInt32(data[7])),
                                period_time_technical_inspection = data[8],
                                sent_repair = Convert.ToBoolean(Convert.ToInt32(data[9])),
                                day_sending_repair = data[10],
                                number_repairs = Convert.ToInt32(data[11]),
                                number_flights_repaired = Convert.ToInt32(data[12])
                            };
                            planes.Add(p);
                        }
                        else
                        {
                            Console.WriteLine($"Plane Continue: {line}");
                        }
                    }
                }
            }
        }

        public void GetOllPlanes()
        {
            DisplayPlanes(p => true);
        }

        public void GetOllPlanesAtSpecifiedTime(string time)
        {
            DisplayPlanes(p => p.time_arrival_airport == time);
        }

        public void GetOllNumberFlightsMade(int number)
        {
            DisplayPlanes(p => p.number_flights_made == number);
        }

        public void GetOllPeriodTimeTechnical(string period)
        {
            DisplayPlanes(p => p.period_time_technical_inspection == period);
        }

        public void GetOllDaySendingRepair(string daySendingRepair)
        {
            DisplayPlanes(p => p.day_sending_repair == daySendingRepair);
        }

        public void GetOllNumberRepairs(int numberRepairs)
        {
            DisplayPlanes(p => p.number_repairs == numberRepairs);
        }

        public void GetOllNumberFlightsRepaired(int numberFlightsRepaired)
        {
            DisplayPlanes(p => p.number_flights_repaired == numberFlightsRepaired);
        }

        public void GetOllAgeAircraft(int ageAircraft)
        {
            DisplayPlanes(p => p.age_aircraft == ageAircraft);
        }

        private void DisplayPlanes(Predicate<Plane> predicate)
        {
            int numberOfPlanes = 0;
            foreach (Plane p in planes.FindAll(predicate))
            {
                DataOutputPlane(p);
                numberOfPlanes++;
            }
            Console.WriteLine($"\nNumber of planes: {numberOfPlanes}");
        }
    }
}
