﻿using System;
using System.Collections.Generic;
using System.IO;

namespace KursovaArcheticture
{
    class Program
    {
        static void Main()
        {
            //Console.BackgroundColor = ConsoleColor.White;
            //Console.ForegroundColor = ConsoleColor.Black;
            Menu m = new Menu();

            using (StreamReader welcomePage = new StreamReader("WelcomePage.txt"))
            {
                //Console.BackgroundColor = ConsoleColor.White;
                string templine;
                while ((templine = welcomePage.ReadLine()) != null)
                {
                    Console.WriteLine(templine);
                    Thread.Sleep(30);
                }
            }

            int choice;
            Console.WriteLine("\t\t\tEnter 1 to continue, 0 to exit");
            if (int.TryParse(Console.ReadLine(), out choice))
            {
                if (choice == 1)
                {
                    m.Administration();
                    m.menu();
                }
            }else
             {
                Console.WriteLine("Invalid input.");
             }
        }
    }
}
