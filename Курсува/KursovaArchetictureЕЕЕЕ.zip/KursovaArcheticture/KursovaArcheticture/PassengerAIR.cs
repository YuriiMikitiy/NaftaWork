﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace KursovaArcheticture
{
    public class Passenger
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public char Gender { get; set; }
        public string Flight { get; set; }
        public string DepartureDay { get; set; }
        public bool FlewAbroad { get; set; }
        public bool CheckedLuggage { get; set; }
        public int PlaceRow { get; set; }
        public int PlaceNumber { get; set; }
        public bool HandTicket { get; set; }
        public int TicketPrice { get; set; }
        public string DepartureTime { get; set; }
    }

    public class PassengerAIR
    {
        private List<Passenger> passengers = new List<Passenger>();
        private const string FilePath = "Passenger.txt";

        public PassengerAIR()
        {
            if (File.Exists(FilePath))
            {
                var lines = File.ReadAllLines(FilePath);
                foreach (var line in lines)
                {
                    var data = line.Split(' ');
                    if (data.Length >= 12)
                    {
                        passengers.Add(new Passenger
                        {
                            Name = data[0],
                            Age = int.Parse(data[1]),
                            Gender = char.Parse(data[2]),
                            Flight = data[3],
                            DepartureDay = data[4],
                            FlewAbroad = Convert.ToBoolean(int.Parse(data[5])),
                            CheckedLuggage = Convert.ToBoolean(int.Parse(data[6])),
                            PlaceRow = int.Parse(data[7]),
                            PlaceNumber = int.Parse(data[8]),
                            HandTicket = Convert.ToBoolean(int.Parse(data[9])),
                            TicketPrice = int.Parse(data[10]),
                            DepartureTime = data[11]
                        });
                    }
                }
            }
        }

        public void AddPassenger()
        {
            var p = new Passenger();
            p.Name = ReadInput("Enter passenger's name: ");
            p.Age = int.Parse(ReadInput("Enter passenger's age: "));
            p.Gender = char.Parse(ReadInput("Enter passenger's gender (M/F): "));
            p.Flight = ReadInput("Enter flight number: ");
            p.DepartureDay = ReadInput("Enter departure day: ");
            p.FlewAbroad = Convert.ToBoolean(int.Parse(ReadInput("Did the passenger fly abroad? (1 for Yes, 0 for No): ")));
            p.CheckedLuggage = Convert.ToBoolean(int.Parse(ReadInput("Does the passenger have checked luggage? (1 for Yes, 0 for No): ")));
            p.PlaceRow = int.Parse(ReadInput("Enter seat row: "));
            p.PlaceNumber = int.Parse(ReadInput("Enter seat number: "));
            p.HandTicket = Convert.ToBoolean(int.Parse(ReadInput("Does the passenger have a hand ticket? (1 for Yes, 0 for No): ")));
            p.TicketPrice = int.Parse(ReadInput("Enter ticket price: "));
            p.DepartureTime = ReadInput("Enter departure time: ");

            if (Audit(p.PlaceRow, p.PlaceNumber))
            {
                Console.WriteLine("Error: The selected seat is already occupied. Please try again.");
                return;
            }

            passengers.Add(p);
            WritePassengerToFile(p);
            Console.Clear();
        }

        public void UpdatePassenger(string name)
        {
            var passengerToUpdate = passengers.FirstOrDefault(p => p.Name == name);
            if (passengerToUpdate != null)
            {
                Console.WriteLine($"Updating passenger: {name}");
                passengerToUpdate.Age = int.Parse(ReadInput("Enter passenger's age: "));
                passengerToUpdate.Gender = char.Parse(ReadInput("Enter passenger's gender (M/F): "));
                passengerToUpdate.Flight = ReadInput("Enter flight number: ");
                passengerToUpdate.DepartureDay = ReadInput("Enter departure day: ");
                passengerToUpdate.FlewAbroad = Convert.ToBoolean(int.Parse(ReadInput("Did the passenger fly abroad? (1 for Yes, 0 for No): ")));
                passengerToUpdate.CheckedLuggage = Convert.ToBoolean(int.Parse(ReadInput("Does the passenger have checked luggage? (1 for Yes, 0 for No): ")));
                passengerToUpdate.PlaceRow = int.Parse(ReadInput("Enter seat row: "));
                passengerToUpdate.PlaceNumber = int.Parse(ReadInput("Enter seat number: "));
                passengerToUpdate.HandTicket = Convert.ToBoolean(int.Parse(ReadInput("Does the passenger have a hand ticket? (1 for Yes, 0 for No): ")));
                passengerToUpdate.TicketPrice = int.Parse(ReadInput("Enter ticket price: "));
                passengerToUpdate.DepartureTime = ReadInput("Enter departure time: ");

                RewritePassengersToFile();
                Console.Clear();
            }
            else
            {
                Console.WriteLine($"Passenger with name {name} not found.");
            }
        }

        public void DeletePassenger(string name)
        {
            var passengerToDelete = passengers.FirstOrDefault(p => p.Name == name);
            if (passengerToDelete != null)
            {
                passengers.Remove(passengerToDelete);
                RewritePassengersToFile();
                Console.WriteLine($"Passenger with name {name} deleted.");
            }
            else
            {
                Console.WriteLine($"Passenger with name {name} not found.");
            }
        }

        private void RewritePassengersToFile()
        {
            File.WriteAllText(FilePath, string.Empty);
            foreach (var p in passengers)
            {
                WritePassengerToFile(p);
            }
        }

        private void WritePassengerToFile(Passenger p)
        {
            using (var file = new StreamWriter(FilePath, true))
            {
                file.WriteLine($"{p.Name} {p.Age} {p.Gender} {p.Flight} {p.DepartureDay} {Convert.ToInt32(p.FlewAbroad)} " +
                    $"{Convert.ToInt32(p.CheckedLuggage)} {p.PlaceRow} {p.PlaceNumber} {Convert.ToInt32(p.HandTicket)} " +
                    $"{p.TicketPrice} {p.DepartureTime}");
            }
        }

        public void DataOutputPassenger(Passenger p)
        {
            Console.WriteLine($"Name: {p.Name}");
            Console.WriteLine($"Age: {p.Age}");
            Console.WriteLine($"Gender: {p.Gender}");
            Console.WriteLine($"Flight: {p.Flight}");
            Console.WriteLine($"Departure day: {p.DepartureDay}");
            Console.WriteLine($"Flew abroad: {(p.FlewAbroad ? "Yes" : "No")}");
            Console.WriteLine($"Checked luggage: {(p.CheckedLuggage ? "Yes" : "No")}");
            Console.WriteLine($"Place row: {p.PlaceRow}");
            Console.WriteLine($"Place number: {p.PlaceNumber}");
            Console.WriteLine($"Ticket price: {p.TicketPrice}");
            Console.WriteLine($"Departure time: {p.DepartureTime}");
            Console.WriteLine();
        }

        public bool Audit(int placeRow, int placeNumber)
        {
            return passengers.Any(p => p.PlaceRow == placeRow && p.PlaceNumber == placeNumber);
        }

        public void GetAllPassengersDepartedSpecifiedDay(string departureDay)
        {
            var result = passengers.Where(p => p.DepartureDay == departureDay).ToList();
            OutputPassengerList(result, "Number of passengers: ");
        }

        public void GetAllPassengersDepartedSpecifiedDayFlewAbroad(string departureDay)
        {
            var result = passengers.Where(p => p.DepartureDay == departureDay && p.FlewAbroad).ToList();
            OutputPassengerList(result, "Number of passengers: ");
        }

        public void GetAllPassengersCheckedBaggage(bool checkedLuggage)
        {
            var result = passengers.Where(p => p.CheckedLuggage == checkedLuggage).ToList();
            OutputPassengerList(result, "Number of passengers: ");
        }

        public void GetAllPassengersGender(char gender)
        {
            var result = passengers.Where(p => p.Gender == gender).ToList();
            OutputPassengerList(result, "Number of passengers: ");
        }

        public void GetAllPassengersAge(int age)
        {
            var result = passengers.Where(p => p.Age == age).ToList();
            OutputPassengerList(result, "Number of passengers: ");
        }

        public void GetAllNumbersAge(int age)
        {
            var result = passengers.Count(p => p.Age == age && p.HandTicket);
            Console.WriteLine($"\nThe number of issued tickets: {result}");
        }

        public void GetAllNumbersGender(char gender)
        {
            var result = passengers.Count(p => p.Gender == gender && p.HandTicket);
            Console.WriteLine($"\nThe number of issued tickets: {result}");
        }

        public void GetFreeReservedPlacesFlight(string flight)
        {
            OutputFreeReservedPlaces(p => p.Flight == flight);
        }

        public void GetFreeReservedPlacesDepartureDay(string departureDay)
        {
            OutputFreeReservedPlaces(p => p.DepartureDay == departureDay);
        }

        public void GetFreeReservedPlacesTicketPrice(int ticketPrice)
        {
            OutputFreeReservedPlaces(p => p.TicketPrice == ticketPrice);
        }

        public void GetFreeReservedPlacesDepartureTime(string departureTime)
        {
            OutputFreeReservedPlaces(p => p.DepartureTime == departureTime);
        }

        private void OutputPassengerList(List<Passenger> passengers, string message)
        {
            passengers.ForEach(DataOutputPassenger);
            Console.WriteLine($"\n{message} {passengers.Count}");
        }

        private void OutputFreeReservedPlaces(Func<Passenger, bool> predicate)
        {
            var reservedSeats = passengers.Where(predicate).Select(p => new { p.PlaceRow, p.PlaceNumber }).ToList();

            Console.WriteLine("Reserved seats: ");
            reservedSeats.ForEach(seat => Console.Write($"{seat.PlaceRow}:{seat.PlaceNumber}  "));
            Console.WriteLine();

            Console.WriteLine("Free places: ");
            for (int i = 1; i <= 8; i++)
            {
                for (int n = 1; n <= 9; n++)
                {
                    if (!reservedSeats.Any(seat => seat.PlaceRow == i && seat.PlaceNumber == n))
                    {
                        Console.Write($"{i}:{n}  ");
                    }
                }
            }

            Console.WriteLine($"\nThe number of reserved seats: {reservedSeats.Count}");
            Console.WriteLine($"\nThe number of free places: {72 - reservedSeats.Count}");
        }

        private string ReadInput(string prompt)
        {
            Console.Write(prompt);
            return Console.ReadLine();
        }
    }
}
