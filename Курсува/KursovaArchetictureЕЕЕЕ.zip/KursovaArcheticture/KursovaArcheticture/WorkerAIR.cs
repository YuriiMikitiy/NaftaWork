﻿
using System;
using System.Collections.Generic;
using System.IO;

namespace KursovaArcheticture
{
    public class Worker
    {
        public string Name { get; set; }
        public int Age { get; set; }
        public int Department { get; set; }
        public bool IsDepartmentHead { get; set; }
        public int Brigade { get; set; }
        public string Flight { get; set; }
        public int ExperienceYears { get; set; }
        public char Gender { get; set; }
        public bool HasChildren { get; set; }
        public int NumberChildren { get; set; }
        public int Salary { get; set; }
        public int MedicalExamination { get; set; }
        public int YearMedicalExamination { get; set; }
    }

    public class WorkerAIR
    {
        private List<Worker> workers = new List<Worker>();
        private const string FilePath = "Worker.txt";

        public void AddWorker()
        {
            Worker w = InputWorkerData();
            workers.Add(w);
            WriteWorkerToFile(w);
            Console.Clear();
        }

        public void UpdateWorker(string name)
        {
            Worker workerToUpdate = workers.Find(w => w.Name == name);
            if (workerToUpdate != null)
            {
                Console.WriteLine($"Updating worker: {name}");
                InputWorkerData(workerToUpdate);
                RewriteWorkersToFile();
                Console.Clear();
            }
            else
            {
                Console.WriteLine($"Worker with name {name} not found.");
            }
        }

        public void DeleteWorker(string name)
        {
            Worker workerToDelete = workers.Find(w => w.Name == name);
            if (workerToDelete != null)
            {
                workers.Remove(workerToDelete);
                RewriteWorkersToFile();
                Console.WriteLine($"Worker with name {name} deleted.");
            }
            else
            {
                Console.WriteLine($"Worker with name {name} not found.");
            }
        }

        private Worker InputWorkerData(Worker w = null)
        {
            w ??= new Worker();

            Console.WriteLine("Enter worker's name: ");
            w.Name = Console.ReadLine();

            Console.WriteLine("Enter worker's age: ");
            w.Age = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter worker's department: ");
            w.Department = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Is the worker a department head? (1 for Yes, 0 for No): ");
            w.IsDepartmentHead = Convert.ToBoolean(Convert.ToInt32(Console.ReadLine()));

            Console.WriteLine("Enter worker's brigade: ");
            w.Brigade = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter the flight the worker serves: ");
            w.Flight = Console.ReadLine();

            Console.WriteLine("Enter worker's experience (years): ");
            w.ExperienceYears = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter worker's gender (M/F): ");
            w.Gender = Convert.ToChar(Console.ReadLine());

            Console.WriteLine("Does the worker have children? (1 for Yes, 0 for No): ");
            w.HasChildren = Convert.ToBoolean(Convert.ToInt32(Console.ReadLine()));

            if (w.HasChildren)
            {
                Console.WriteLine("Enter the number of children the worker has: ");
                w.NumberChildren = Convert.ToInt32(Console.ReadLine());
            }
            else
            {
                w.NumberChildren = 0;
            }

            Console.WriteLine("Enter worker's salary: ");
            w.Salary = Convert.ToInt32(Console.ReadLine());

            if (w.Department == 1)
            {
                Console.WriteLine("Enter worker's medical examination result: ");
                w.MedicalExamination = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter the year of worker's last medical examination: ");
                w.YearMedicalExamination = Convert.ToInt32(Console.ReadLine());
            }
            else
            {
                w.MedicalExamination = 0;
                w.YearMedicalExamination = 0;
            }

            return w;
        }

        private void RewriteWorkersToFile()
        {
            File.WriteAllText(FilePath, string.Empty);
            foreach (Worker w in workers)
            {
                WriteWorkerToFile(w);
            }
        }

        private void WriteWorkerToFile(Worker w)
        {
            using (StreamWriter file = new StreamWriter(FilePath, true))
            {
                file.WriteLine($"{w.Name} {w.Age} {w.Department} {Convert.ToInt32(w.IsDepartmentHead)} " +
                    $"{w.Brigade} {w.Flight} {w.ExperienceYears} {w.Gender} {Convert.ToInt32(w.HasChildren)} " +
                    $"{w.NumberChildren} {w.Salary} {w.MedicalExamination} {w.YearMedicalExamination}");
            }
        }

        public void DataOutput(Worker w)
        {
            Console.WriteLine($"Name: {w.Name}");
            Console.WriteLine($"Age: {w.Age}");
            Console.WriteLine($"Department: {w.Department}");
            Console.WriteLine($"Is department head: {(w.IsDepartmentHead ? "Yes" : "No")}");
            Console.WriteLine($"Brigade: {w.Brigade}");
            Console.WriteLine($"The flight it serves: {w.Flight}");
            Console.WriteLine($"Experience (years): {w.ExperienceYears}");
            Console.WriteLine($"Gender: {w.Gender}");
            Console.WriteLine($"Has children: {(w.HasChildren ? "Yes" : "No")}");
            Console.WriteLine($"Number of children: {w.NumberChildren}");
            Console.WriteLine($"Salary: {w.Salary}");
            Console.WriteLine($"Medical Examination: {w.MedicalExamination}");
            Console.WriteLine($"Year of Medical Examination: {w.YearMedicalExamination}");
            Console.WriteLine();
        }

        public WorkerAIR()
        {
            if (File.Exists(FilePath))
            {
                using (StreamReader file = new StreamReader(FilePath))
                {
                    string line;
                    while ((line = file.ReadLine()) != null)
                    {
                        string[] data = line.Split(' ');

                        if (data.Length >= 13)
                        {
                            Worker w = new Worker()
                            {
                                Name = data[0],
                                Age = Convert.ToInt32(data[1]),
                                Department = Convert.ToInt32(data[2]),
                                IsDepartmentHead = Convert.ToBoolean(Convert.ToInt32(data[3])),
                                Brigade = Convert.ToInt32(data[4]),
                                Flight = data[5],
                                ExperienceYears = Convert.ToInt32(data[6]),
                                Gender = Convert.ToChar(data[7]),
                                HasChildren = Convert.ToBoolean(Convert.ToInt32(data[8])),
                                NumberChildren = Convert.ToInt32(data[9]),
                                Salary = Convert.ToInt32(data[10]),
                                MedicalExamination = Convert.ToInt32(data[11]),
                                YearMedicalExamination = Convert.ToInt32(data[12])
                            };
                            workers.Add(w);
                        }
                    }
                }
            }
        }

        private void DisplayWorkers(Predicate<Worker> predicate)
        {
            int numberOfEmployees = 0;
            foreach (Worker w in workers.FindAll(predicate))
            {
                DataOutput(w);
                numberOfEmployees++;
            }
            Console.WriteLine($"\nNumber of employees: {numberOfEmployees}");
        }

        public void PrintWorkersWithExperience(int experience)
        {
            DisplayWorkers(w => w.ExperienceYears == experience);
        }

        public void GetOllWorkers()
        {
            DisplayWorkers(w => true);
        }

        public void GetOllDepartmentHeads()
        {
            DisplayWorkers(w => w.IsDepartmentHead);
        }

        public void GetOllEmployeesDepartment(int department)
        {
            DisplayWorkers(w => w.Department == department);
        }

        public void GetOllEmployeeSexualCharacteristic(char gender)
        {
            DisplayWorkers(w => w.Gender == gender);
        }

        public void GetOllEmployeesAge(int age)
        {
            DisplayWorkers(w => w.Age == age);
        }

        public void GetOllEmployeesNumberChildren(int numberChildren)
        {
            DisplayWorkers(w => w.NumberChildren == numberChildren);
        }

        public void GetOllEmployeeSalary(int salary)
        {
            DisplayWorkers(w => w.Salary == salary);
        }

        public void GetOllEmployeeInBrigade(int brigade)
        {
            DisplayWorkers(w => w.Brigade == brigade);
        }

        public void GetOllEmployeeInOllBrigade()
        {
            DisplayWorkers(w => w.Brigade != 0);
        }

        public void GetOllEmployeeServingSpecificFlight(string flight)
        {
            DisplayWorkers(w => w.Flight == flight);
        }

        public void GetOllEmployeeTotalAverageSalaryBrigade(int brigade)
        {
            int numberOfEmployees = 0;
            int totalSalary = 0;
            foreach (Worker w in workers.FindAll(w => w.Brigade == brigade))
            {
                DataOutput(w);
                numberOfEmployees++;
                totalSalary += w.Salary;
            }
            Console.WriteLine($"\nNumber of employees: {numberOfEmployees}");
            if (numberOfEmployees > 0)
            {
                Console.WriteLine($"Total average salary in brigade: {totalSalary / numberOfEmployees}");
            }
        }

        public void GetOllPilotsMedicalExamination()
        {
            DisplayWorkers(w => w.MedicalExamination == 1);
        }

        public void GetOllPilotsNotMedicalExaminationYear(int year)
        {
            DisplayWorkers(w => w.YearMedicalExamination == year);
        }

        public void GetOllEmployeeGenderPilots(char gender)
        {
            DisplayWorkers(w => w.Gender == gender && w.Department == 1);
        }

        public void GetOllPilotsAge(int age)
        {
            DisplayWorkers(w => w.Age == age && w.Department == 1);
        }

        public void GetOllPilotsSalary(int salary)
        {
            DisplayWorkers(w => w.Salary == salary && w.Department == 1);
        }
    }
}